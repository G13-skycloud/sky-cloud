package cn.zju.action;

import java.io.File;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

import org.apache.struts2.ServletActionContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import cn.zju.dao.po.Group;
import cn.zju.dao.po.Relation;
import cn.zju.dao.po.User;
import cn.zju.service.FileService;
import cn.zju.service.GroupService;
import cn.zju.service.RelationService;
import cn.zju.service.UserService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class JoinGroupAction extends ActionSupport implements Serializable{

	private String username;
	private String password; 
	private String invitecode;
	
	private String groupname;
	
	private RelationService relationservice; 
	private Relation relation;
	private UserService userservice; 
	private User user;
	private GroupService groupservice; 
	private Group group;


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getInvitecode() {
		return invitecode;
	}

	public void setInvitecode(String invitecode) {
		this.invitecode = invitecode;
	}

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public RelationService getService() {
		return relationservice;
	}

	public void setService(RelationService service) {
		this.relationservice = relationservice;
	}

	public Relation getRelation() {
		return relation;
	}

	public void setRelation(Relation relation) {
		this.relation = relation;
	}

	public UserService getUserservice() {
		return userservice;
	}

	public void setUserservice(UserService userservice) {
		this.userservice = userservice;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public GroupService getGroupservice() {
		return groupservice;
	}

	public void setGroupservice(GroupService groupservice) {
		this.groupservice = groupservice;
	}

	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
	
	//当进行注册前，检查参数是否正确
	public void validateLogup(){
		String user_name = (String) ActionContext.getContext().getSession().get("user_name");
		String user_password= (String) ActionContext.getContext().getSession().get("user_password");
		if("".equals(user_name) || "".equals(user_password) || "".equals(invitecode)){
			ServletActionContext.getRequest().setAttribute("usernameerror", "用户名必须6-20位");
			ServletActionContext.getRequest().setAttribute("passworderror", "密码必须6-20位");
			ServletActionContext.getRequest().setAttribute("invitecodeerror", "邀请码必须4-16位");
		    addFieldError("", "");
		    return ;
	    }
		if(user_name.length() > 20 || user_name.length() < 6){
			ServletActionContext.getRequest().setAttribute("usernameerror", "用户名必须6-20位");
	        addFieldError("", "");
		}
		if(user_password.length() > 20 || user_password.length() < 6){
			ServletActionContext.getRequest().setAttribute("passworderror", "密码必须6-20位");
			addFieldError("", "");
		}
		if(invitecode.length() >16 || invitecode.length() < 4){
			ServletActionContext.getRequest().setAttribute("invitecodeerror", "邀请码必须4-16位");
			addFieldError("", "");
		}
	}
	
	public String joingroup(){


		try {
			int userid = userservice.getUserid(username);
			int groupid = groupservice.getGroupid(groupname);
			
			//session域存的user_name和传进来的username一致，说明用户名没有造假
			String user_name = (String) ActionContext.getContext().getSession().get("user_name");
			String user_password= (String) ActionContext.getContext().getSession().get("user_password");
			if(user_name == null || "".equals(user_name) || !user_name.equals(this.username))
				if(user_password == null || "".equals(user_password) || !user_password.equals(this.password))
					return SUCCESS;
			
			relation.setUserid(userid);
			relation.setGroupid(groupid);
			relation.setJointime(new java.util.Date());
			//如果用户已加入该群组 下层的service会抛出异常
			
			
			//加入成功，就更新数据库
			relationservice.insertRelation(relation);
			ServletActionContext.getRequest().setAttribute("message", "上传成功！");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			ServletActionContext.getRequest().setAttribute("usernameerror", "该用户已注册");
			return ERROR;
		}
	}
}
