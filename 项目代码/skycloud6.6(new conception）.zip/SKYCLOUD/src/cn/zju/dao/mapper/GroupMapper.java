package cn.zju.dao.mapper;

import java.util.List;

import cn.zju.action.NewDeleteFileAction;
import cn.zju.action.NewUploadAction;
//import cn.zju.action.SearchFileAction;
import cn.zju.action.SearchGroupAction;
//import cn.zju.action.SearchUserFileAction;
import cn.zju.action.SearchUserGroupAction;
//import cn.zju.dao.po.File;
import cn.zju.dao.po.Group;

public interface GroupMapper {
	public void createGroup(Group group) throws Exception;
	public String checkGroup(Group group) throws Exception;
	public Integer findGroup(String groupname) throws Exception;
	public Integer getGroupId(String groupname) throws Exception;
	public List<Group> getUserGroups(SearchUserGroupAction action)throws Exception;
	public List<Group> getAllGroups(SearchGroupAction action)throws Exception;
	public int countGroups(SearchGroupAction searchGroupAction) throws Exception;
	public int countUserGroups(SearchUserGroupAction action) throws Exception;
	public Integer hasMemberNum(String groupname)throws Exception;
	public Integer limitMemberNum(String groupname)throws Exception;
	public String inviteCode(String groupname)throws Exception;
	public void minusHasMemberNum(String groupname)throws Exception;
	public void plusHasMemberNum(String groupname)throws Exception;
	public String getGroupName(int groupid)throws Exception;
	public void deleteGroupById(int groupid)throws Exception;
	public String getArceusById(int groupid)throws Exception;
	public int totalCapa(String group_name)throws Exception;
	public int usedCapa(String group_name)throws Exception;
	public void plusUsedCapa(NewUploadAction action)throws Exception;
	public void minusUsedCapa(NewDeleteFileAction action)throws Exception;
}
