package cn.zju.action;

import java.io.File;
import java.io.Serializable;

import org.apache.struts2.ServletActionContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.zju.service.FileService;
import cn.zju.service.GroupService;
 
public class NewDeleteFileAction extends ActionSupport implements Serializable{
	
	private int currentpage;
	private int pagesize;
	private int startindex;
	private int id; //文件id
	private FileService service; 
	private GroupService groupservice; 
	private String group_name;
	private long size;
	
	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getGroup_name() {
		return group_name;
	}

	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}

	public void setService(FileService service) {
		this.service = service;
	}
	
	public int getStartindex() {
		return startindex;
	}

	public void setStartindex(int startindex) {
		this.startindex = startindex;
	}

	public int getCurrentpage() {
		return currentpage;
	}

	public void setCurrentpage(int currentpage) {
		this.currentpage = currentpage;
	}
	
	public int getPagesize() {
		return pagesize;
	}

	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	public String deleteFile(){
	   //System.out.println(id);	
	   
	   //判断该用户是否拥有此文件
	   try{
		   String groupname = service.findFilepathById(id);
		   int groupid = groupservice.getGroupId(groupname);
		   String arceus = groupservice.getArceusById(groupid);
		   
		   String adminname = (String) ActionContext.getContext().getSession().get("admin_name");
		   String username=(String) ActionContext.getContext().getSession().get("user_name");
		   String login_user = username;
		   if(adminname==null || adminname.equals("")) {
			   //不是管理员在操作
			   login_user = (String) ActionContext.getContext().getSession().get("user_name");
		   }
		   else {
			   //是管理员在操作
			   if(!(username==null || "".equals(username) )) {
				   login_user = arceus;
			   }
			   else {
				   ServletActionContext.getRequest().setAttribute("globalmessage", "文件已不存在");
				   return ERROR;
			   }
		   }

		   String filename = service.findFilenameById(id); //查出文件名

		   if(arceus!=null && login_user.equals(arceus) ){
			   service.deleteFileById(id); //删除数据库的该文件记录
			   //从硬盘上删除文件
			   String storepath = new String("C:"+File.separator+"upload"+File.separator+groupname+File.separator);
			   storepath = storepath+filename;
			   System.out.println(storepath);
			   File file = new File(storepath);
			   if(file.exists()){
				   file.delete();
			   }else{
				   ServletActionContext.getRequest().setAttribute("globalmessage", "文件已不存在");
				   return ERROR;
			   }
			   //todo 修改usedcapa
				try {
					long filesize=service.getFilesizeByName(filename);
					long usedcapa=groupservice.usedCapa(groupname);
					//long totalcapa=groupservice.totalCapa(groupname);
					if((usedcapa-filesize)<0) {
						ServletActionContext.getRequest().setAttribute("message", "删除失败！群容量可能出现了问题！");
						return SUCCESS;
					}
					else {
						this.setGroup_name(groupname);
						this.setSize(filesize);
						groupservice.minusUsedCapa(this);			
					}
				}catch(Exception e) {
		    			ServletActionContext.getRequest().setAttribute("message", "上传失败！你的容量可能已经不足！");
		    			return SUCCESS;
				}
			   return SUCCESS;
		   }else{ //不通过，可能是人为篡改数据，转发至全局消息页面
			ServletActionContext.getRequest().setAttribute("globalmessage", "你可能没有权利删除");
			return ERROR;
		   }
	   }catch(Exception e){
		   e.printStackTrace();
		   ServletActionContext.getRequest().setAttribute("globalmessage", "你可能没有权利删除");
		   return ERROR;
	   }
	}
}
