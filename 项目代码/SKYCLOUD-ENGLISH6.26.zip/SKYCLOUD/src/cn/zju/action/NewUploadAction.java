package cn.zju.action;

import java.io.File;
import java.io.Serializable;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;


import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.zju.service.FileService;
import cn.zju.service.GroupService;
import cn.zju.service.UserService;

public class NewUploadAction extends ActionSupport implements Serializable{
	
	private String groupname;
	private long size;
	private File file;  //对应的就是表单中文件上传的那个输入域的名称，Struts2框架会封装成File类型的
	private String fileFileName;//   上传输入域+FileName  文件名  JavaWeb.pdf
	private String fileContentType;// 上传文件的MIME类型  application/pdf

	private static final String storePath = "C:"+File.separator+"upload"; //存储目录 C:\\upload
	private static final int normallimit = 20*1000*1000; //普通用户上传单个文件的最大体积 20mb
	private static final int viplimit = 50*1000*1000; //普通用户上传单个文件的最大体积 50mb
	private static final int factor = 1000000;  //Mb到字节的转换因子
	
	private FileService fileService; 
	private UserService userService; 
	private GroupService groupService; 
	private cn.zju.dao.po.File f ;
	
	
	public long getSize() {
		return size;
	}
	public void setSize(long size) {
		this.size = size;
	}
	public void setF(cn.zju.dao.po.File f) {
		this.f = f;
	}
	public void setFileService(FileService fileService) {
		this.fileService = fileService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}
	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public FileService getFileService() {
		return fileService;
	}
	public UserService getUserService() {
		return userService;
	}
	public GroupService getGroupService() {
		return groupService;
	}
	public void setGroupService(GroupService groupService) {
		this.groupService = groupService;
	}
	
	public String upload() throws Exception{
		
		//session域存的username和传进来的username一致，说明用户名没有造假
		String user_name = (String) ActionContext.getContext().getSession().get("user_name");
		String group_name = (String) ActionContext.getContext().getSession().get("group_name");
		if(user_name == null || "".equals(user_name) )
			 return SUCCESS;
		
		//从数据库查询该用户是否为vip 
		Integer isvip = null;
		try {
			isvip = userService.isVip(user_name);
			//把是否是vip的信息带到userhome主页，用于在客户端限制文件上传大小
			ServletActionContext.getRequest().setAttribute("isvip", isvip);
		} catch (Exception e) {
			e.printStackTrace();
			ServletActionContext.getRequest().setAttribute("message", "sommthing wrong,please try later");
			return SUCCESS;
		}  
		
		File store = null;  //目的文件
	   	try{
    		//存在每个用户有一个自己名字命名的文件夹
    		 store = new File(storePath+File.separator+group_name,fileFileName);
	    	}catch (Exception e) {
	    		ServletActionContext.getRequest().setAttribute("message", "please choose file first！");
	    		return SUCCESS;
	    	}
	   	
	   	long filesize = this.file.length() ;  //上传文件的大小
	   	
		if(SUCCESS.equals(checkFile(store, storePath, isvip, filesize)))//检查文件大小等是否符合要求
			return SUCCESS; //有问题 转发回用户空间页面显示原因

		Integer fileid = null;
		try {
			//todo 检查用户的云空间是否超过限额
			long usedcapa=groupService.usedCapa(group_name);
			long totalcapa=groupService.totalCapa(group_name);
			if(((filesize/1024+1)+usedcapa)>totalcapa) {
				ServletActionContext.getRequest().setAttribute("message", "failed！your capacity is not enough！");
				return SUCCESS;
			}
			else {
				this.setGroupname(group_name);
				this.setSize((filesize/1024+1));
				//userservice.minusUsedCapa(this);	
				groupService.plusUsedCapa(this);			
			}
			
			//验证全部通过，把文件复制到本地硬盘的用户的目录下
			FileUtils.copyFile(file,store);   //上传文件到本地硬盘
			//把文件信息存入数据库
			f.setCreatetime(new java.util.Date());
			f.setFilename(fileFileName);
			f.setFilepath(groupname);
			f.setFilesize(String.valueOf(filesize/1024+1));
			f.setCanshare(0);
			
		    fileid = fileService.insertFile(f);
			
			ServletActionContext.getRequest().setAttribute("message", "upload sucess！");
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			if(store.exists()){ //中途出现异常，把拷贝的文件删除
				store.delete();
			}
			if(fileid!=null){
				fileService.deleteFileById(fileid);
			}
			ServletActionContext.getRequest().setAttribute("message", "failed!please try later");
			return SUCCESS;
		}
	}

    private String checkFile(File store , String storePath , int isvip , long size){
 
    		
		if(store.exists()){
			ServletActionContext.getRequest().setAttribute("message", "the file has been existed");
			return SUCCESS;
		}
		
		if( size == 0 ){
			ServletActionContext.getRequest().setAttribute("message", "file size cannot be 0");
			return SUCCESS;
		}else if(isvip == 0 && size > normallimit){
			ServletActionContext.getRequest().setAttribute("message", "normal user's limited upload size is "+normallimit/factor+"Mb!");
			return SUCCESS;
		}else if(isvip == 1 && size > viplimit){
			ServletActionContext.getRequest().setAttribute("message", "VIP user's limited upload size is"+viplimit/factor+"Mb!");
			return SUCCESS;
		}else  return "OK";
     }
 }

