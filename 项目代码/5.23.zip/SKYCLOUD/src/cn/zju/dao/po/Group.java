package cn.zju.dao.po;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("group")
@Scope("prototype")
public class Group{
		private int id;
		private String groupname;
		private int hasmembernum;
		private String Arceus;
		private int limitmembernum;
		private String invitecode;
		
		public String getInvitecode() {
			return invitecode;
		}
		public void setInvitecode(String invitecode) {
			this.invitecode = invitecode;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getGroupname() {
			return groupname;
		}
		public void setGroupname(String groupname) {
			this.groupname = groupname;
		}
		public int getHasmembernum() {
			return hasmembernum;
		}
		public void setHasmembernum(int hasmembernum) {
			this.hasmembernum = hasmembernum;
		}
		public String getArceus() {
			return Arceus;
		}
		public void setArceus(String string) {
			Arceus = string;
		}
		public int getLimitmembernum() {
			return limitmembernum;
		}
		public void setLimitmembernum(int limitmembernum) {
			this.limitmembernum = limitmembernum;
		}
			
}