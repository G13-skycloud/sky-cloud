package cn.zju.dao;


import org.apache.ibatis.session.SqlSession;

import cn.zju.dao.mapper.GroupMapper;
import cn.zju.dao.mapper.RelationMapper;
import cn.zju.dao.po.Group;
import cn.zju.dao.po.Relation;


public class RelationDao {
	
	//创建关系
	public void insertRelation(Relation relation) throws Exception{
		SqlSession session = DaoUtil.getSqlSession();
		RelationMapper mapper = session.getMapper(RelationMapper.class);
		mapper.insertRelation(relation);
		session.commit();
		session.close();
	}
	//查看数据库里是否存在匹配的关系记录 
	public int checkRelation(Relation relation)throws Exception{
		SqlSession session = DaoUtil.getSqlSession();
		RelationMapper mapper = session.getMapper(RelationMapper.class);
		int userid = mapper.checkRelation(relation);
		session.close();
		return userid;
	}
	
	//查找指定关系号的关系是否存在
	public Boolean findRelation(int id) throws Exception{
		SqlSession session = DaoUtil.getSqlSession();
		RelationMapper mapper = session.getMapper(RelationMapper.class);
		Integer found = mapper.findRelation(id);
		session.close();
		if(id<1)  return false;
		return true;
	}
}