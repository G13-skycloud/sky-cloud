package cn.zju.dao.mapper;

import java.util.List;

//import cn.zju.action.SearchFileAction;
import cn.zju.action.SearchGroupAction;
//import cn.zju.action.SearchUserFileAction;
import cn.zju.action.SearchUserGroupAction;
//import cn.zju.dao.po.File;
import cn.zju.dao.po.Group;

public interface GroupMapper {
	public void createGroup(Group group) throws Exception;
	public String checkGroup(Group group) throws Exception;
	public Integer findGroup(String groupname) throws Exception;
	public Integer getGroupid(String groupname) throws Exception;
	public List<Group> getUserGroups(SearchUserGroupAction action)throws Exception;
	public List<Group> getAllGroups(SearchGroupAction action)throws Exception;
	public int countGroups(SearchGroupAction searchGroupAction) throws Exception;
	public int countUserGroups(SearchUserGroupAction action) throws Exception;
	public Integer hasMemberNum(String group_name)throws Exception;
	public Integer limitMemberNum(String group_name)throws Exception;
	public String inviteCode(String group_name)throws Exception;
}
