package cn.zju.dao.mapper;

import cn.zju.dao.po.Relation;


public interface RelationMapper {
	public void insertRelation(Relation relation) throws Exception;
	public Integer findRelation(int id) throws Exception;
	public Integer checkRelation(Relation relation) throws Exception;
}
