package cn.zju.action;

import java.io.File;
import java.io.Serializable;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import cn.zju.dao.po.User;
//import cn.zju.service.FileService;
import cn.zju.service.UserService;

import cn.zju.dao.po.Group;
import cn.zju.service.GroupService;


public class CreateGroupAction extends ActionSupport implements Serializable{
	
	private String groupname;
	private String invitecode;
	private GroupService service; 
	private Group group;
	

	public String getInvitecode() {
		return invitecode;
	}

	public void setInvitecode(String invitecode) {
		this.invitecode = invitecode;
	}
	
	public void setGroup(Group group) {
		this.group =group;
	}
	
	public void setService(GroupService service) {
		this.service = service;
	}
	
	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public Group getGroup() {
		return group;
	}

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
	
	//当进行创建群组前，检查参数是否正确
	public void validateLogup(){
		
		if("".equals(groupname) || "".equals(invitecode)){
			ServletActionContext.getRequest().setAttribute("groupnameerror", "用户名必须6-20位");
			ServletActionContext.getRequest().setAttribute("invitecodeerror", "邀请码必须4-16位");
		    addFieldError("", "");
	    }else if(groupname.length() > 20 || groupname.length() < 6){
			ServletActionContext.getRequest().setAttribute("groupnameerror", "用户名必须6-20位");
	        addFieldError("", "");
		}else if(invitecode.length() > 16 || invitecode.length() < 4){
			ServletActionContext.getRequest().setAttribute("invitecoodeerror", "邀请码必须4-16位");
			addFieldError("", "");
		}
	}
	
	public String creategroup(){	
		group.setGroupname(groupname);
		group.setInvitecode(invitecode);
		//group.setArceus("tester");
		try {
			String username = (String) ActionContext.getContext().getSession().get("user_name");
			//session没有用户名说明没有登陆，让他转去主页
			if(username==null || "".equals(username)){
				return INPUT;
			}
			group.setArceus(username);
			service.createGroup(group); //如果群组已注册 下层的service会抛出异常
			//注册成功，就在upload下分配一个群组文件夹
			String path = ServletActionContext.getServletContext().getRealPath("WEB-INF/groupupload");
			File file = new File(path+File.separator+groupname);
			file.mkdir();
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			ServletActionContext.getRequest().setAttribute("groupnameerror", "wrong");
			return ERROR;
		}
	}
}
