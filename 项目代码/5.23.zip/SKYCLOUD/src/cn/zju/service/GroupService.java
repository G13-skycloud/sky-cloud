package cn.zju.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import cn.zju.action.SearchFileAction;
import cn.zju.action.SearchGroupAction;
//import cn.zju.action.SearchUserFileAction;
import cn.zju.action.SearchUserGroupAction;
import cn.zju.dao.mapper.GroupMapper;
//import cn.zju.dao.po.File;
import cn.zju.dao.po.Group;

@Service(value="groupService")
public class GroupService {
	
	@Autowired
	private GroupMapper dao;

	public void createGroup(Group group) throws Exception{
		Boolean found = findGroup(group.getGroupname());
		if(!found)
		   dao.createGroup(group);
		else
			throw new RuntimeException();
	}
	
	public String checkGroup(Group group) throws Exception{
		return dao.checkGroup(group);
	}
	
	public boolean findGroup(String groupname) throws Exception{
		Integer found = dao.findGroup(groupname);
		if(found==null || found<1)  return false;
		return true;
	}
	
	public int getGroupid(String groupname) throws Exception{
		Integer found = dao.getGroupid(groupname);
		if(found==null || found<1)  return 0;
		return found;
	}

	public  List<Group> getUserGroups(SearchUserGroupAction action) throws Exception {
		return dao.getUserGroups(action);
	}
	
	public  List<Group> getAllGroups(SearchGroupAction searchGroupAction) throws Exception{
		return dao.getAllGroups(searchGroupAction);
	}
	
	public  int countGroups(SearchGroupAction searchGroupAction)throws Exception{
		return dao.countGroups(searchGroupAction);
	}
	
	public  int countUserGroups(SearchUserGroupAction action) throws Exception {
		return dao.countUserGroups(action);
	}
	
	public int hasMemberNum(String group_name)throws Exception {
		return dao.hasMemberNum(group_name);
	}
	
	public int limitMemberNum(String group_name)throws Exception{
		return dao.limitMemberNum(group_name);
	}
	
	public String inviteCode(String group_name)throws Exception{
		return dao.inviteCode(group_name);
	}
	

}
